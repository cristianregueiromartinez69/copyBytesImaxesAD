
package copybytesimaxes;


/**
 * clase main dond ejecutamos el programa
 * @author cristian
 * @version 1.0
 */
public class CopybytesImaxes {


    public static void main(String[] args) {
    	//objeto del menu y llamamos al metodo para iniciar la aplicacion
        Menu menu = new Menu();
        menu.mainMenu();
    }
    
}
